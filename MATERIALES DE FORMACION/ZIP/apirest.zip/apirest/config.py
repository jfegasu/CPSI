
import requests
configura={
    "STATIC_FOLDERS":"static",
    "TEMPLATE_FOLDER":"templates",
    "DEBUG":True,
    "SERVER_NAME":"http://127.0.0.1",
    "SERVER_API":"http://127.0.0.1:5000",
    "PUERTOREST":5000,
    "PUERTOAPP":8000,
    "MODULO":"salud",
    "SMBD":"SQLITE",
    "DB":"./configura.db"
}
