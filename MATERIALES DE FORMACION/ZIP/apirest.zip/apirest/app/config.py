from dotenv import load_dotenv
load_dotenv()

'''
class DevelopmentConfig{
    DEBUG=True
    HOST='localhos:8000'
}

class config:
    #STATIC_FOLDERS="static"
    #TEMPLATE_FOLDER="templates"
    DEBUG=True
    SERVER_NAME="http://127.0.0.1:7001"

'''